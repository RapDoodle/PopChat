#pragma once

#include <QWidget>
#include "ui_entranceForm.h"

class entranceForm : public QWidget
{
	Q_OBJECT

public:
	entranceForm(QWidget *parent = Q_NULLPTR);
	~entranceForm();

private:
	Ui::entranceForm ui;
};
