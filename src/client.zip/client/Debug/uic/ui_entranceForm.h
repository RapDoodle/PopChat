/********************************************************************************
** Form generated from reading UI file 'entranceForm.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENTRANCEFORM_H
#define UI_ENTRANCEFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_entranceForm
{
public:

    void setupUi(QWidget *entranceForm)
    {
        if (entranceForm->objectName().isEmpty())
            entranceForm->setObjectName(QString::fromUtf8("entranceForm"));
        entranceForm->resize(400, 300);

        retranslateUi(entranceForm);

        QMetaObject::connectSlotsByName(entranceForm);
    } // setupUi

    void retranslateUi(QWidget *entranceForm)
    {
        entranceForm->setWindowTitle(QCoreApplication::translate("entranceForm", "entranceForm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class entranceForm: public Ui_entranceForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENTRANCEFORM_H
