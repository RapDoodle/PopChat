/********************************************************************************
** Form generated from reading UI file 'chatForm.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATFORM_H
#define UI_CHATFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_chatForm
{
public:

    void setupUi(QWidget *chatForm)
    {
        if (chatForm->objectName().isEmpty())
            chatForm->setObjectName(QString::fromUtf8("chatForm"));
        chatForm->resize(400, 300);

        retranslateUi(chatForm);

        QMetaObject::connectSlotsByName(chatForm);
    } // setupUi

    void retranslateUi(QWidget *chatForm)
    {
        chatForm->setWindowTitle(QCoreApplication::translate("chatForm", "chatForm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class chatForm: public Ui_chatForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATFORM_H
