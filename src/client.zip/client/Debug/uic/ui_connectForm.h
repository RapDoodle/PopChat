/********************************************************************************
** Form generated from reading UI file 'connectForm.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONNECTFORM_H
#define UI_CONNECTFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_connectFormClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *connectFormClass)
    {
        if (connectFormClass->objectName().isEmpty())
            connectFormClass->setObjectName(QString::fromUtf8("connectFormClass"));
        connectFormClass->resize(600, 400);
        menuBar = new QMenuBar(connectFormClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        connectFormClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(connectFormClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        connectFormClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(connectFormClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        connectFormClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(connectFormClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        connectFormClass->setStatusBar(statusBar);

        retranslateUi(connectFormClass);

        QMetaObject::connectSlotsByName(connectFormClass);
    } // setupUi

    void retranslateUi(QMainWindow *connectFormClass)
    {
        connectFormClass->setWindowTitle(QCoreApplication::translate("connectFormClass", "connectForm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class connectFormClass: public Ui_connectFormClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONNECTFORM_H
