#include "entranceForm.h"

entranceForm::entranceForm(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

entranceForm::~entranceForm()
{
}
