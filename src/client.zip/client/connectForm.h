#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_connectForm.h"

class connectForm : public QMainWindow
{
    Q_OBJECT

public:
    connectForm(QWidget *parent = Q_NULLPTR);

private:
    Ui::connectFormClass ui;
};
