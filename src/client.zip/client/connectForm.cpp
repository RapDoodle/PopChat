#include "connectForm.h"

connectForm::connectForm(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
