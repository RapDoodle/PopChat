#include "chatForm.h"

chatForm::chatForm(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

chatForm::~chatForm()
{
}
